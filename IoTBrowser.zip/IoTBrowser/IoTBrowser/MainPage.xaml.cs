﻿// Copyright (c) Microsoft. All rights reserved.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoTBrowser
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            webView.Navigate(new Uri("http://192.168.1.74"));
        }

        private void camera_click_on(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Camera));
        }
        

        private void coffee_maker_click_on(object sender, RoutedEventArgs e)
        {
            webView.Navigate(new Uri("http://192.168.1.74/COFFEE_MAKER=ON"));
        }
        private void coffee_maker_click_off(object sender, RoutedEventArgs e)
        {
            webView.Navigate(new Uri("http://192.168.1.74/COFFEE_MAKER=OFF"));
        }

        private void light_click_on(object sender, RoutedEventArgs e)
        {
            webView.Navigate(new Uri("http://192.168.1.74/LIGHT=ON"));
        }
        private void light_click_off(object sender, RoutedEventArgs e)
        {
            webView.Navigate(new Uri("http://192.168.1.74/LIGHT=OFF"));
        }

        private void fan_click_on(object sender, RoutedEventArgs e)
        {
            webView.Navigate(new Uri("http://192.168.1.74/FAN=ON"));
        }
        private void fan_click_off(object sender, RoutedEventArgs e)
        {
            webView.Navigate(new Uri("http://192.168.1.74/FAN=OFF"));
        }
    }
}
